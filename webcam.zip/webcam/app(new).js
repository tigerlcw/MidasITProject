var express = require('express')
var bodyParser = require('body-parser')
var fs = require('fs')
var path = require('path')
var https = require('https')
var ejs = require('ejs')
var app = express()
var io = require('socket.io')(https)
var port = process.env.PORT || 3000;
/*var options = {
    key: fs.readFileSync('soylatte.kr_20170221I7NV.key.pem'),
    cert: fs.readFileSync('soylatte.kr_20170221I7NV.crt.pem')
};*/

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, '/public')));

https.createServer( options, app).listen(port, (err)=>{
    if(err){
        console.log('Server Error!')
        throw err
    }
    else {
        console.log('Server Running At 3000 Port!');
    }
});

io.on('connection', (socket)=>{
    socket.on('stream', (image)=>{
        socket.broadcast.emit('stream',image)
    })
})


app.get('/', (req, res)=>{
    res.render('vir')
})

app.get('/server', (req, res)=>{
    res.render('emtir')
    }
)