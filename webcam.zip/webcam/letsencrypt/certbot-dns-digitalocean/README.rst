DigitalOcean DNS Authenticator plugin for Certbot
