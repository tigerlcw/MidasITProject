"""DigitalOcean DNS Authenticator"""
