"""Google Cloud DNS Authenticator"""
