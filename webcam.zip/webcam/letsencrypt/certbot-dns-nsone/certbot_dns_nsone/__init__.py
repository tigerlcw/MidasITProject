"""NS1 DNS Authenticator"""
